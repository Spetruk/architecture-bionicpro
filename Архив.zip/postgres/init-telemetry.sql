-- Создание таблицы телеметрии в основной БД
CREATE TABLE IF NOT EXISTS telemetry_data (
    user_id INTEGER,
    prosthesis_type VARCHAR(50),
    muscle_group VARCHAR(50), 
    signal_frequency INTEGER,
    signal_duration INTEGER,
    signal_amplitude DECIMAL(5,2),
    recorded_at TIMESTAMP,
    battery_level INTEGER,
    movement_accuracy DECIMAL(5,2)
);

-- Вставка тестовых данных телеметрии
INSERT INTO telemetry_data VALUES 
(1, 'arm_prosthesis', 'biceps', 120, 500, 75.5, '2024-01-15 10:30:00', 85, 92.3),
(1, 'arm_prosthesis', 'triceps', 110, 450, 68.2, '2024-01-15 11:00:00', 83, 89.1),
(1, 'arm_prosthesis', 'forearm', 130, 520, 82.1, '2024-01-15 11:30:00', 84, 95.7),
(2, 'leg_prosthesis', 'quadriceps', 100, 600, 90.5, '2024-01-15 09:00:00', 78, 88.4),
(2, 'leg_prosthesis', 'hamstring', 95, 580, 85.3, '2024-01-15 09:30:00', 76, 91.2),
(2, 'leg_prosthesis', 'calf', 105, 520, 78.9, '2024-01-15 10:00:00', 75, 87.6),
(3, 'arm_prosthesis', 'forearm', 115, 480, 72.1, '2024-01-15 08:30:00', 90, 93.8),
(3, 'arm_prosthesis', 'biceps', 130, 520, 81.4, '2024-01-15 09:00:00', 89, 96.2);
